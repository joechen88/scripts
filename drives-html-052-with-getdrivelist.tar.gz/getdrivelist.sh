#
#  get ssd and hdd list
#
#

PROG=`basename $0`

HDD=""
SSD=""

usage() {
cat << EOF


    $PROG [flags]

    Flags that take arguments:
    -h|--help:

    Usage:

        $PROG -d hdd.csv -s ssd.csv

        [ Note: first download hdd.csv and ssd.csv from https://www.vmware.com/resources/compatibility/search.php?deviceCategory=vsanio ]


EOF
}

while [ $# -ge 1 ]
do
   case "$1" in
    -h|--help)
       usage
       exit 0
       ;;
    -d|--hdd)
       shift
       HDD=$1
       ;;
    -s|--ssd)
       shift
       SSD=$1
       ;;
    -*)
       echo "Not implemented: $1" >&2
       exit 1
       ;;
    *)
       break
       exit 0
       ;;
   esac
   shift
done

getHDD(){
    echo "read HDD info..."
    readCSV.py hdd $1 > hdd.txt
    drive.py hdd hdd.txt drives.html
    #insert after after forHDD is found
    sed -e '/forHDD/r hddout.txt' drives.html > a.html
    rm hddout.txt
    rm hdd.txt
    rm drives.html
    mv a.html drives.html
    echo "done updating HDD..."
    rm $1
}

getSSD(){
    echo "read SSD info..."
    readCSV.py ssd $1 > ssd.txt
    drive.py ssd ssd.txt drives.html
    #insert before forSSD
    sed -e '/forSSD/r ssdout.txt' -e //N drives.html > b.html
    rm ssdout.txt
    rm ssd.txt
    rm drives.html
    mv b.html drives.html
    echo "done updating SSD..."
    rm $1
}

timeStamp(){
   old_TS=$(cat drives.html | grep -iE "Last updated:" | awk '{print $3}')
   new_TS=$(date '+%D')
   sed -e "s|$old_TS|$new_TS|g" drives.html > c.html
   rm drives.html
   mv c.html drives.html
   echo "Done updating timestamp..."
}

getHDD $HDD
getSSD $SSD
timeStamp
